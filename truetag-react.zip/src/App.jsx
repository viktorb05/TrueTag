import React from 'react'

export default function App() {
  return (
    <div className="container">
      <h1>Welcome to TrueTag</h1>
      <p>Smart security meets smart branding.</p>
    </div>
  )
}